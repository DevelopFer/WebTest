<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="card mb-3">
					<img class="card-img-top img-fluid" src="<?php echo e(url('/uploads/'.$post->imageurl)); ?>" alt="<?php echo e($post->title); ?>}">
					<div class="card-body">
						<h1 class="card-title"><b><?php echo e($post->title); ?></b></h1>
						<div class="row">
							<div class="col-4">
								<i class="fas fa-calendar"></i>&nbsp;<small class="text-muted">Publisehd <?php echo e(date('F, jS Y')); ?></small>
							</div>
							<div class="col-4">
								<i class="fas fa-user"></i>&nbsp;<small class="text-muted"><?php echo e($post->user->name); ?></small>
							</div>
							<div class="col-4">
								<i class="fas fa-tags"></i>
								<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<span class="badge badge-pill badge-info" style="color:#FFFFFF"><?php echo e($tag->name); ?></span>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<p class="card-text"><?php echo html_entity_decode($post->body); ?></p>
						<a href="<?php echo e(url()->previous()); ?>" class="card-link">Go Back</a>
					</div>
 				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.posts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>