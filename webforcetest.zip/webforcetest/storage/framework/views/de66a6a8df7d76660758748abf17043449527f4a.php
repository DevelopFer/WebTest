<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
                <?php if(count($posts) <=  0): ?>
                    <div class="jumbotron jumbotron-fluid">
                        <div class="container">
                            <h1 class="display-4">We don't have any post yet</h1>
                            <p class="lead">Register for creating a free account and share your amazing posts with the world .</p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-lg-6" style="margin-bottom:15px;">
                        <div class="card " >
                            <img src="<?php echo e(url('/uploads/'.$post->imageurl)); ?>" class="card-img-top img-thumbnail img-fluid" alt="<?php echo e($post->title); ?>" style="max-height:280px">
                            <div class="card-body">
                            <h2 class="card-title"><b><?php echo e($post->title); ?></b></h2>
                            <i class="fas fa-tags"></i>
                                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-pill badge-info" style="color:#FFFFFF"><?php echo e($tag->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <p class="card-text postcard"><?php echo e(strip_tags($post->body)); ?></p>
                                <a href="<?php echo e(route('showPost',['slug' => $post->slug])); ?>" class="btn btn-primary">Read More</a>
                                <p class="card-text">
                                    <small class="text-muted">Published <?php echo e(date('d/m/Y H:m', strtotime($post->created_at))); ?></small>
                                </p>
                            </div>
                        </div>    
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.posts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>